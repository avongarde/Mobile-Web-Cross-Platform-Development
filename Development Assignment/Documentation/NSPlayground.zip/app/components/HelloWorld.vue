<template>
    <Page class="page">
        <ActionBar title="Simple Expense Tracker v0.02" class="action-bar" />

        <ScrollView>

            <StackLayout class="home-panel form input-field">
                <!-- <Label text="Store and retrieve data locally by using Application Settings (similar to 'local storage' on the web)."
                    textWrap="true" class="lbl" /> -->
                <StackLayout orientation="horizontal" horizontalAlignment="center">
                    <Button text="Expense Entry" @tap="onButtonTap" class="btn btn-primary" />
                    <Button text="Income Entry" @tap="onButtonTap" class="btn btn-primary" />

                </StackLayout>
                <StackLayout orientation="horizontal" horizontalAlignment="center">
                    <Button text="Expense Ledger" @tap="onButtonTap" class="btn btn-primary" />
                    <Button text="Expense List" @tap="onButtonTap" class="btn btn-primary" />

                </StackLayout>
                <!-- store/retrieve string -->
                <!-- <Label text="Enter an income source" class="heading" />
                <TextField v-model="str" hint="Name..." class="input input-border" />
                <StackLayout orientation="horizontal" horizontalAlignment="center">
                    <!-- <Button text="Save" @tap="saveString" class="btn btn-primary" />
                    <Button text="Remove" @tap="removeString" class="btn btn-primary" /> -->
                <!-- </StackLayout> --> -->

                <!-- store/retrieve number -->
                <!-- <Label text="Enter an amount" class="heading" />
                <TextField v-model="num" hint="Cost..." class="input input-border"
                    keyboardType="number" />
                <StackLayout orientation="horizontal" horizontalAlignment="center">
                    <Button text="Submit" @tap="saveNumber" class="btn btn-primary" />
                    <!-- <Button text="Remove" @tap="removeNumber" class="btn btn-primary" /> -->
                <!-- </StackLayout> --> -->

                <!-- store/retrieve boolean
                <Label text="Boolean" class="heading" />
                <Switch v-model="bool" class="switch" />
                 -->

                <ListView class="list-group" for="country in countries"
                    @itemTap="onItemTap" style="height:600px">
                    <v-template>
                        <FlexboxLayout flexDirection="row" class="list-group-item">

                            <Label :text="country.name" class="list-group-item-heading"
                                style="width: 60%" />
                            <Label :text="country.imageSrc" class="list-group-text" />
                        </FlexboxLayout>
                    </v-template>
                </ListView>

                <StackLayout class="hr-light" />
                <Label text="You currently owe 650 dollars!" textWrap="true"
                    class="lbl" />
                <Button text="Reset Inputs" @tap="removeAll" class="btn btn-primary" />


            </StackLayout>
        </ScrollView>
    </Page>
</template>

<script>
    const appSettings = require("tns-core-modules/application-settings");
    const dialogs = require("tns-core-modules/ui/dialogs");
    export default {
        data() {
            return {
                countries: [{
                        name: "Work",
                        imageSrc: "500"
                    },
                    {
                        name: "Rent",
                        imageSrc: "-1000"
                    },
                    {
                        name: "Food",
                        imageSrc: "-100"
                    },
                    {
                        name: "Gas",
                        imageSrc: "-50"
                    }
                ],

                segmentedBarItems: (function() {
                    var segmentedBarModule = require(
                        "ui/segmented-bar");
                    let segmentedBarItem1 = new segmentedBarModule.SegmentedBarItem();
                    segmentedBarItem1.title = "Item 1";
                    let segmentedBarItem2 = new segmentedBarModule.SegmentedBarItem();
                    segmentedBarItem2.title = "Item 2";
                    return [segmentedBarItem1, segmentedBarItem2];
                })(),
                selectedBarIndex: 0,

                selectedListPickerIndex: 0,

                num: null,
                str: "",
                bool: false
            };
        },
        created() {
            // second parameter is default value
            this.num = appSettings.getNumber("someNumber", null);
            this.str = appSettings.getString("someString", "");
            this.bool = appSettings.getBoolean("someBoolean", false);
        },

        methods: {
            onItemTap: function(args) {
                console.log("Item with index: " + args.index + " tapped");
            },

            onButtonTap() {
                console.log("Button was pressed");
            },

            saveNumber() {
                appSettings.setNumber("someNumber", parseFloat(this.num));
                dialogs.alert("You saved: " + appSettings.getNumber(
                    "someNumber"));
            },
            removeNumber() {
                appSettings.remove("someNumber");
                dialogs.alert("You removed the number from app settings!");
                this.num = null;
            },
            saveString() {
                appSettings.setString("someString", this.str);
                dialogs.alert("You saved: " + appSettings.getString(
                    "someString"));
            },
            removeString() {
                appSettings.remove("someString");
                dialogs.alert("You removed the string from app settings!");
                this.str = "";
            },
            saveBoolean() {
                appSettings.setBoolean("someBoolean", this.bool);
                dialogs.alert(
                    "You saved: " + appSettings.getBoolean("someBoolean")
                );
            },
            removeBoolean() {
                appSettings.remove("someBoolean");
                dialogs.alert("You removed the boolean from app settings!");
                this.bool = false;
            },
            removeAll() {
                appSettings.clear();
                dialogs.alert("All app settings values have been cleared!");
                this.num = null;
                this.str = "";
                this.bool = false;
            }
        }
    };
</script>